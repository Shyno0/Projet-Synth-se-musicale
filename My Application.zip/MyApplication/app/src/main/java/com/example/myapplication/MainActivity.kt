package com.example.myapplication

import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.Chronometer
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var chronometer: Chronometer
    private lateinit var editTextNumber: EditText
    private var isRunning = false
    private var pauseOffset: Long = 0
    private var durationInMillis: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chronometer = findViewById(R.id.chronometer)
        editTextNumber = findViewById(R.id.editTextNumber)

        val buttonMarche = findViewById<Button>(R.id.buttonMarche)
        val buttonPause = findViewById<Button>(R.id.buttonPause)
        val buttonArret = findViewById<Button>(R.id.buttonArret)

        // Stop le minuteur si le temps est écoulé
        chronometer.setOnChronometerTickListener {
            val elapsedMillis = SystemClock.elapsedRealtime() - chronometer.base
            if (elapsedMillis >= durationInMillis) {
                chronometer.stop()
                isRunning = false
            }
        }

        buttonMarche.setOnClickListener {
            val minutesText = editTextNumber.text.toString()
            val minutes = minutesText.toLongOrNull() ?: 20
            durationInMillis = minutes * 60 * 1000

            if (!isRunning) {
                chronometer.base = SystemClock.elapsedRealtime() - pauseOffset
                chronometer.start()
                isRunning = true
            }
        }

        buttonPause.setOnClickListener {
            if (isRunning) {
                pauseOffset = SystemClock.elapsedRealtime() - chronometer.base
                chronometer.stop()
                isRunning = false
            } else {
                chronometer.base = SystemClock.elapsedRealtime() - pauseOffset
                chronometer.start()
                isRunning = true
            }
        }

        buttonArret.setOnClickListener {
            chronometer.stop()
            chronometer.base = SystemClock.elapsedRealtime()
            pauseOffset = 0
            isRunning = false
        }
    }
}
