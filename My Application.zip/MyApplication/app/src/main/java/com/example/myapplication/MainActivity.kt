package com.example.myapplication

import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.widget.Chronometer
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val chronometer = findViewById<Chronometer>(R.id.chronometer)
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.radioButton -> {
                    Log.i("ApplicationTP2", "Appui sur Marche")
                    // Réinitialise le chronomètre pour repartir de zéro
                    chronometer.base = SystemClock.elapsedRealtime()
                    chronometer.start()
                }
                R.id.radioButton2 -> {
                    Log.i("ApplicationTP2", "Appui sur Arrêt")
                    chronometer.stop()
                }
                else -> {
                    Log.i("ApplicationTP2", "Aucun bouton reconnu")
                }
            }
        }
    }
}
