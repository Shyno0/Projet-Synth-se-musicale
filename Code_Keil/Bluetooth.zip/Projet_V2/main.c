/*----------------------------------------------------------------------------
 * Name:    Demo.c
 * Purpose: Demo example for MCBSTM32F200
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2004-2018 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/

#include "stdint.h"
#include "cmsis_os.h"                   // ARM::CMSIS:RTOS:Keil RTX
#include "Driver_USART.h"                   // Device header
#include "stm32f2xx.h"                  // Device header
#include "stm32f2xx_hal_conf.h"         // Keil::Device:STM32Cube Framework:Classic
#include "Board_LED.h"                  // ::Board Support:LED
#include "RTE_Device.h"                 // Keil::Device:STM32Cube Framework:Classic


// Main stack size must be multiple of 8 Bytes
#define APP_MAIN_STK_SZ (1024U)
uint64_t app_main_stk[APP_MAIN_STK_SZ / 8];

extern ARM_DRIVER_USART Driver_USART1;

/*-----------------------------------------------------------------------------
  Draw vertical line at specified coordinates (x,y) with specified height (h)
 *----------------------------------------------------------------------------*/
/*static void DrawRuler (uint32_t x, uint32_t y, uint32_t h) {
  uint32_t i;

  for (i = 0; i < h; i++) {
    GLCD_DrawPixel (x, y - i);
  }
}
*/
/*----------------------------------------------------------------------------
 * Application main thread
 *---------------------------------------------------------------------------*/
		uint8_t rx_buffer[10];
char tx_buffer[10]="123456789";

/*void USART1_callback(uint32_t event) {
    if (event & ARM_USART_EVENT_RECEIVE_COMPLETE) {
        // Les donn�es ont �t� re�ues, traite-les ici
        // Exemple : renvoyer en �cho
        Driver_USART1.Send(rx_buffer, sizeof(rx_buffer));
    }
}*/
extern void app_main(void const *argument);

osThreadDef(app_main, osPriorityNormal, 1, 0);
int i;
void Init_USART1(void){
	    /*Initialize the USART driver */
    Driver_USART1.Initialize(NULL); //mettre le CALLBACK apr�s essai
	
    /*Power up the USART peripheral */
    Driver_USART1.PowerControl(ARM_POWER_FULL);
    /*Configure the USART to 9600 Bits/sec */
    Driver_USART1.Control(ARM_USART_MODE_ASYNCHRONOUS |
                      ARM_USART_DATA_BITS_8 |
                      ARM_USART_PARITY_NONE |
                      ARM_USART_STOP_BITS_1 |
                      ARM_USART_FLOW_CONTROL_NONE, 9600);
     
    /* Enable Receiver and Transmitter lines */
    Driver_USART1.Control (ARM_USART_CONTROL_TX, 1);
    Driver_USART1.Control (ARM_USART_CONTROL_RX, 1);
}
int main(void) {
		LED_Initialize();
		Init_USART1();
    osKernelInitialize();                      // Initialiser le kernel RTX
		osThreadCreate(osThread(app_main), NULL);
    osKernelStart();                           // D�marrer l'ordonnanceur RTX
    while (1) {
        // Ne jamais arriver ici
    }
}
void app_main (void const *argument) {
  while(1)
	{
		for(i=0; i<10;i++){
			Driver_USART1.Send(&tx_buffer[i], 1);
			LED_On(0);
		} 
		osDelay(100);
    LED_Off(0);
		LED_On(1);		
    osDelay(500);
		LED_Off(1);
	}
}
