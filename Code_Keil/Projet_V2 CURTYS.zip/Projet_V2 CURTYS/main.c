#include "stdint.h"
#include "cmsis_os.h"
#include "Driver_USART.h"
#include "Board_LED.h"

extern ARM_DRIVER_USART Driver_USART1;

void app_main(void const *argument);  // <-- D�claration pr�alable

osThreadDef(app_main, osPriorityNormal, 1, 0);

uint8_t rx_char;

void Init_USART1(void) {
    Driver_USART1.Initialize(NULL);
    Driver_USART1.PowerControl(ARM_POWER_FULL);
    Driver_USART1.Control(ARM_USART_MODE_ASYNCHRONOUS |
                          ARM_USART_DATA_BITS_8 |
                          ARM_USART_PARITY_NONE |
                          ARM_USART_STOP_BITS_1 |
                          ARM_USART_FLOW_CONTROL_NONE, 9600);
    Driver_USART1.Control(ARM_USART_CONTROL_TX, 1);
    Driver_USART1.Control(ARM_USART_CONTROL_RX, 1);
}

void app_main(void const *argument) {
    while (1) {
        // Re�oit un caract�re en mode bloquant
        if (Driver_USART1.Receive(&rx_char, 1) == ARM_DRIVER_OK) {
            // Attendre la r�ception compl�te
            while (Driver_USART1.GetRxCount() < 1) {
                osDelay(1);
            }

            // Allumer LED0 si caract�re 'a' re�u, sinon �teindre
            if (rx_char == 'a') {
                LED_On(0);
                osDelay(5000);
                LED_Off(0);
            }
        }
    }
}

int main(void) {
    LED_Initialize();
    Init_USART1();

    osKernelInitialize();
    osThreadCreate(osThread(app_main), NULL);
    osKernelStart();

    while (1) {}
}
