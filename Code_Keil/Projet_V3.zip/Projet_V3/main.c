#include "stm32f2xx_hal.h"

#define TABLE_SIZE 256

// Ta table sinuso�de statique (exemple simplifi�)
const uint16_t sine_wave[TABLE_SIZE] = {
  2048, 2098, 2148, 2198, 2248, /* ... compl�te avec tes valeurs ... */ 2048
};

DAC_HandleTypeDef hdac;
TIM_HandleTypeDef htim6;
DMA_HandleTypeDef hdma_dac1;

void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitStruct.Pin = GPIO_PIN_4;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;

    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void MX_DAC_Init(void)
{
    DAC_ChannelConfTypeDef sConfig;

    __HAL_RCC_DAC_CLK_ENABLE();

    hdac.Instance = DAC;
    if (HAL_DAC_Init(&hdac) != HAL_OK) {
        // Gestion erreur
        while(1);
    }

    sConfig.DAC_Trigger = DAC_TRIGGER_T6_TRGO;
    sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;

    if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK) {
        while(1);
    }
}

void MX_TIM6_Init(void)
{
    TIM_MasterConfigTypeDef sMasterConfig;

    __HAL_RCC_TIM6_CLK_ENABLE();

    htim6.Instance = TIM6;
    htim6.Init.Prescaler = 84 - 1;   // Exemple: APB1 � 84 MHz ? 1 MHz timer clock
    htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim6.Init.Period = 1000 - 1;    // 1 kHz fr�quence
    htim6.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if (HAL_TIM_Base_Init(&htim6) != HAL_OK) {
        while(1);
    }

    sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;

    if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK) {
        while(1);
    }
}

void MX_DMA_Init(void)
{
    __HAL_RCC_DMA1_CLK_ENABLE();

    hdma_dac1.Instance = DMA1_Stream5;
    hdma_dac1.Init.Channel = DMA_CHANNEL_7;
    hdma_dac1.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_dac1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_dac1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_dac1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_dac1.Init.Mode = DMA_CIRCULAR;
    hdma_dac1.Init.Priority = DMA_PRIORITY_LOW;
    hdma_dac1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;

    if (HAL_DMA_Init(&hdma_dac1) != HAL_OK) {
        while(1);
    }

    __HAL_LINKDMA(&hdac, DMA_Handle1, hdma_dac1);
}

int main(void)
{
    int i;  // D�claration en haut de la fonction

    HAL_Init();

    SystemClock_Config();

    MX_GPIO_Init();
    MX_DMA_Init();
    MX_DAC_Init();
    MX_TIM6_Init();

    // D�marrage du DAC avec DMA sur la table sinuso�de statique
    if (HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1, (uint32_t*)sine_wave, TABLE_SIZE, DAC_ALIGN_12B_R) != HAL_OK) {
        while(1);
    }

    // D�marrage du timer qui d�clenche le DAC
    if (HAL_TIM_Base_Start(&htim6) != HAL_OK) {
        while(1);
    }

    while(1)
    {
        // Pas besoin de code ici, DMA et timer g�rent la sortie
    }
}
