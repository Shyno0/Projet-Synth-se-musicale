#include "stm32f2xx_hal.h"
#include <math.h>
#include "stm32f2xx_hal_conf.h"         // Keil::Device:STM32Cube Framework:Classic
#include "Board_LED.h"                  // ::Board Support:LED

#define TABLE_SIZE 256  // Nombre de points pour une sinuso�de (256 points pour une fr�quence de 1 Hz � 256 Hz par exemple)
#define DAC_MAX_VALUE 4095  // Valeur maximale pour le DAC 12 bits

// Table pour stocker les valeurs de la sinuso�de
uint16_t sine_wave[TABLE_SIZE];

// Handle pour le DAC
DAC_HandleTypeDef hdac;

// Handle pour le Timer (utilis� pour d�clencher l'actualisation du DAC)
TIM_HandleTypeDef htim6;

// Handle pour le DMA (utilis� pour transf�rer les donn�es vers le DAC)
DMA_HandleTypeDef hdma_dac1;

// Fonction pour g�n�rer une sinuso�de
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
void generate_sine_wave(void) {
		int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        // G�n�rer une sinuso�de : Valeurs entre 0 et 4095 (pour un DAC 12 bits)
        sine_wave[i] = (uint16_t)(DAC_MAX_VALUE / 2 * (1 + sin(2 * M_PI * i / TABLE_SIZE)));
    }
}

// Initialisation du DAC
DAC_ChannelConfTypeDef sConfig;
void DAC_Init(void) {
    // Activer l'horloge du DAC
    __HAL_RCC_DAC_CLK_ENABLE();

    // Initialiser le DAC
    if (HAL_DAC_Init(&hdac) != HAL_OK) {
        // Si l'initialisation �choue, appeler une fonction d'erreur
			
    }
    // Configurer le DAC (canal 1)
    hdac.Instance = DAC;
    sConfig.DAC_Trigger = DAC_TRIGGER_T6_TRGO;  // Timer 6 d�clenche le DAC
    sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;  // Activer le buffer de sortie

    if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK) {
        // Si la configuration �choue, appeler une fonction d'erreur
    }

    // D�marrer le DAC
    if (HAL_DAC_Start(&hdac, DAC_CHANNEL_1) != HAL_OK) {
        // Si l'activation �choue, appeler une fonction d'erreur
    }
}

// Initialisation du Timer pour g�n�rer des interruptions p�riodiques
void Timer_Init(void) {
    __HAL_RCC_TIM6_CLK_ENABLE();

    htim6.Instance = TIM6;
    htim6.Init.Prescaler = 0;  // Pas de prescaler (fr�quence du timer = fr�quence du bus)
    htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim6.Init.Period = 1000 - 1;  // 1 ms d'intervalle (1kHz pour une p�riode de 1 ms)
    htim6.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if (HAL_TIM_Base_Init(&htim6) != HAL_OK) {
        // Si l'initialisation �choue, appeler une fonction d'erreur
    }

    // Lancer le timer
    HAL_TIM_Base_Start(&htim6);
}

// Initialisation du DMA pour transf�rer les donn�es vers le DAC
void DMA_Init(void) {
    __HAL_RCC_DMA1_CLK_ENABLE();

    hdma_dac1.Instance = DMA1_Stream5;
    hdma_dac1.Init.Channel = DMA_CHANNEL_7;  // Canal DMA appropri� pour le DAC
    hdma_dac1.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_dac1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_dac1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_dac1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_dac1.Init.Mode = DMA_CIRCULAR;  // Mode circulaire pour r�p�ter les transferts
    hdma_dac1.Init.Priority = DMA_PRIORITY_LOW;

    if (HAL_DMA_Init(&hdma_dac1) != HAL_OK) {
        // Si l'initialisation �choue, appeler une fonction d'erreur
    }

    // Relier le DMA au DAC
    __HAL_LINKDMA(&hdac, DMA_Handle1, hdma_dac1);
}

// Fonction pour d�marrer le DMA et remplir le DAC avec la sinuso�de
void Start_DMA(void) {
    // Lancer le transfert DMA vers le DAC
    if (HAL_DMA_Start(&hdma_dac1, (uint32_t)sine_wave, (uint32_t)&DAC->DHR12R1, TABLE_SIZE) != HAL_OK) {
        // Si l'op�ration �choue, appeler une fonction d'erreur
    }
}


void GPIO_Init(void) {
	  GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitStruct.Pin = GPIO_PIN_4;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}
int main(void) {
    // Initialisation de la biblioth�que HAL
		GPIO_Init();
		LED_Initialize();
    HAL_Init();

    // G�n�rer la table de la sinuso�de
    generate_sine_wave();

    // Initialiser le DAC, le Timer et le DMA
    DAC_Init();
    Timer_Init();
    DMA_Init();

    // D�marrer le DMA pour commencer � transf�rer les valeurs
    Start_DMA();

    // Boucle principale
    while (1) {
        // Ici, vous pouvez ajouter d'autres t�ches si n�cessaire
    }
}
